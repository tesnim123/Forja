<?php 
include 'connection/connect.php';
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Choose 3 Movie Genres</title>
    <link rel="stylesheet" href="genress.css">
</head>
<body>

<div class="container">
    <h1>Select 3 Movie Genres</h1>

    <form id="genres-form" method="POST" action="genres.php">
        <div class="genre-grid">
            <div class="genre-card">
                <input type="checkbox" id="action" name="genre[]" value="action">
                <label for="action" class="genre-label">
                    <div class="genre-content">
                        <h3>Action</h3>
                        <p>Adventure, suspense, and intense combat films.</p>
                    </div>
                </label>
            </div>
            <div class="genre-card">
                <input type="checkbox" id="Crime" name="genre[]" value="Crime">
                <label for="Crime" class="genre-label">
                    <div class="genre-content">
                        <h3>Crime</h3>
                        <p>Crime movies explore thrilling tales of lawlessness, suspense, and moral conflict.</p>
                    </div>
                </label>
            </div>
            <div class="genre-card">
                <input type="checkbox" id="drama" name="genre[]" value="drama">
                <label for="drama" class="genre-label">
                    <div class="genre-content">
                        <h3>Drama</h3>
                        <p>Deep and emotional films with powerful stories.</p>
                    </div>
                </label>
            </div>
            
            <div class="genre-card">
                <input type="checkbox" id="romance" name="genre[]" value="romance">
                <label for="romance" class="genre-label">
                    <div class="genre-content">
                        <h3>Romance</h3>
                        <p>Love films with intense emotions and stories.</p>
                    </div>
                </label>
            </div>
            <div class="genre-card">
                <input type="checkbox" id="sci-fi" name="genre[]" value="sci-fi">
                <label for="sci-fi" class="genre-label">
                    <div class="genre-content">
                        <h3>Science-Fiction</h3>
                        <p>Futuristic and extraordinary films.</p>
                    </div>
                </label>
            </div>
            <div class="genre-card">
                <input type="checkbox" id="Adventure" name="genre[]" value="Adventure">
                <label for="Adventure" class="genre-label">
                    <div class="genre-content">
                        <h3>Adventure</h3>
                        <p>Adventure films take you on exciting journeys full of exploration, danger, and discovery.</p>
                    </div>
                </label>
            </div>
            <div class="genre-card">
                <input type="checkbox" id="thriller" name="genre[]" value="thriller">
                <label for="thriller" class="genre-label">
                    <div class="genre-content">
                        <h3>Thriller</h3>
                        <p>Films that keep you on the edge of your seat with suspense.</p>
                    </div>
                </label>
            </div>
            <div class="genre-card">
                <input type="checkbox" id="music" name="genre[]" value="music">
                <label for="music" class="genre-label">
                    <div class="genre-content">
                        <h3>Music</h3>
                        <p>Films that keep you on the edge of your seat with suspense.</p>
                    </div>
                </label>
            </div>
            <div class="genre-card">
                <input type="checkbox" id="comedy" name="genre[]" value="comedy">
                <label for="comedy" class="genre-label">
                    <div class="genre-content">
                        <h3>Comedy</h3>
                        <p>Films that keep you on the edge of your seat with suspense.</p>
                    </div>
                </label>
            </div>
            <div class="genre-card">
                <input type="checkbox" id="Fantasy" name="genre[]" value="Fantasy">
                <label for="Fantasy" class="genre-label">
                    <div class="genre-content">
                        <h3>Fantasy</h3>
                        <p>Films that keep you on the edge of your seat with suspense.</p>
                    </div>
                </label>
            </div>
            <div class="genre-card">
                <input type="checkbox" id="Animation" name="genre[]" value="Animation">
                <label for="Animation" class="genre-label">
                    <div class="genre-content">
                        <h3>Animation</h3>
                        <p>Films that keep you on the edge of your seat with suspense.</p>
                    </div>
                </label>
            </div>
        </div>

        <button type="submit">Submit</button>
    </form>

    <p id="error-message" style="color: red; display: none;">Please select exactly 3 genres.</p>
</div>

<script>
// Script to validate the form and ensure exactly 3 genres are selected
document.getElementById("genres-form").addEventListener("submit", function(event) {
    var selectedGenres = document.querySelectorAll('input[name="genre[]"]:checked');
    if (selectedGenres.length !== 3) {
        event.preventDefault();
        document.getElementById("error-message").style.display = "block";
    } else {
        document.getElementById("error-message").style.display = "none";
    }
});
</script>

<?php
// Process the form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['genre']) && count($_POST['genre']) == 3) {
        $_SESSION['selected_genres'] = $_POST['genre']; // Save the genres in session
        // Redirect to index.php to show movies based on selected genres
        echo "<script>window.location.href='index.php';</script>";
    } else {
        echo "<script>document.getElementById('error-message').style.display = 'block';</script>";
    }
}
?>

</body>
</html>
