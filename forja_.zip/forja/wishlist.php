<?php
// Include the connection file
include 'connection/connect.php';
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    echo "<script>alert('You must be logged in to view your wishlist.');</script>";
    exit;
}

// Get the user_id from the session
$username = $_SESSION['username'];

// Fetch the user_id from the database based on the username
$stmt = $conn->prepare('SELECT user_id FROM users WHERE username = ? LIMIT 1');
$stmt->bind_param('s', $username);  // 's' for string type
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    $stmt->bind_result($user_id);
    $stmt->fetch();
} else {
    die('User not found.');
}
$stmt->close();

// Fetch the wishlist for the logged-in user
$stmt = $conn->prepare('
    SELECT w.wishlist_id, m.movie_id, m.title 
    FROM wishlist w 
    JOIN movies m ON w.movie_id = m.movie_id 
    WHERE w.user_id = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Handle movie removal
if (isset($_GET['delete'])) {
    $wishlist_id = intval($_GET['delete']);
    
    // Remove the movie from the wishlist
    $deleteStmt = $conn->prepare('DELETE FROM wishlist WHERE wishlist_id = ? AND user_id = ?');
    $deleteStmt->bind_param('ii', $wishlist_id, $user_id);
    if ($deleteStmt->execute()) {
        echo "<script>alert('Movie removed from wishlist.');</script>";
        header("Location: wishlist.php");  // Reload the page
    } else {
        echo "<script>alert('Failed to remove movie from wishlist.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link
      href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css"
      rel="stylesheet"
    /><link rel="preconnect" href="https://fonts.googleapis.com">
    <script src="https://kit.fontawesome.com/48967be5bb.js" crossorigin="anonymous"></script>
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <title>Your Wishlist</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: hsl(0, 0%, 20%);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        p{
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            color:red;
        }
        a{
            color:white;
            font-size:18px;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        }

        .container {
            background-color: hsl(228, 13%, 15%);
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 600px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
            color:white;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        }

        .wishlist-item {
            display: flex;
            color:white;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding: 10px;
            background-color: hsl(216, 22%, 18%);
            border-radius: 5px;
        }
        .delete {
  background-color: transparent;
  border: none;
  font-size: 20px; /* Adjusts the size of the button */
  cursor: pointer;
}

.delete ion-icon {
  font-size: 24px; /* Adjusts the size of the icon */
  color: red; /* Change color if desired */
}


        .wishlist-item button {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 5px;
        }

        .wishlist-item button:hover {
            background-color: #c0392b;
        }
        
    .yellow-rectangle {
        text-decoration: none; 
        color: white; 
        background-color: hsl(57, 97%, 45%); 
        padding: 15px 30px; 
        border-radius: 8px; 
        font-size: 18px; 
        font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; 
        display: inline-block; 
        text-align: center;
        transition: background-color 0.3s ease;
    }

    .yellow-rectangle:hover {
        background-color: gray; /* Darker shade of yellow on hover */
    }

    </style>
</head>
<body>

<div class="container">
    <h1>Your Wishlist</h1>

    <?php if ($result->num_rows > 0): ?>
    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="wishlist-item">
            <span><?php echo htmlspecialchars($row['title']); ?></span>
            <!-- Add a trash icon with the confirmDelete function -->
            <button class="delete" onclick="confirmDelete(<?php echo $row['wishlist_id']; ?>)">
                <i class="fa-solid fa-trash"></i>
            </button>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <p>No movies in your wishlist.</p>
<?php endif; ?>

<script>
  // Function to confirm deletion before proceeding
  function confirmDelete(wishlistId) {
    // Ask the user for confirmation
    const confirmation = confirm("Are you sure you want to delete this movie from your wishlist?");
    
    if (confirmation) {
      // If confirmed, redirect to the URL with the delete query
      window.location.href = "wishlist.php?delete=" + wishlistId;
    }
  }
</script>
    <div style="text-align: center; margin-top: 20px;">
        <a href="index.php"class="yellow-rectangle"  >Back to Home</a>
    </div>
    
</div>


</body>
</html>

<?php
// Close the statement and connection
$stmt->close();
$conn->close();
?>
