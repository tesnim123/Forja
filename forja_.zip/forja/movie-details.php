<?php
// Inclure le fichier de connexion
include 'connection/connect.php';
session_start();
if (isset($_SESSION['username'])) {
  // If the user is logged in, display a personalized greeting
  $username = $_SESSION['username'];
  // Fetch the user_id from the database based on the username
$stmt = $conn->prepare('SELECT user_id FROM users WHERE username = ? LIMIT 1');
$stmt->bind_param('s', $username);
$stmt->execute();
$stmt->store_result();

// If the username is found, fetch the user_id
if ($stmt->num_rows > 0) {
    $stmt->bind_result($user_id);
    $stmt->fetch();
    

} else {
    die('User not found.');
}
$stmt->close();// Debugging line to check user_id
} else {
  // If not logged in, set a default username or message
  $username = "Guest";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Movie</title>

  <!-- 
    - favicon
  -->
  <link rel="shortcut icon" href="./favicon.svg" type="image/svg+xml">

  <!-- 
    - custom css link
  -->
  <link rel="stylesheet" href="./assets/css/style.css">

  <!-- 
    - google font link
  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>

<body id="#top">

  <!-- 
    - #HEADER
  -->

  <header class="header" data-header>
    <div class="container">

      <div class="overlay" data-overlay></div>

      <a href="./index.html" class="logo">
        <img src="readme-images/forjafinal1.png" alt="Filmlane logo" width="150" height="50">
      </a>

      <div class="header-actions">

        

      <?php if (isset($_SESSION['username'])): ?>
          
          <a href="logout.php" class="btn btn-secondary"><?= htmlspecialchars($_SESSION['username']); ?></a>
        <?php else: ?>
          <button class="btn btn-primary" onclick="window.location.href='login.php'">Sign In</button>
        <?php endif; ?>

      </div>

      <button class="menu-open-btn" data-menu-open-btn>
        <ion-icon name="reorder-two"></ion-icon>
      </button>

      <nav class="navbar" data-navbar>

        <div class="navbar-top">

          <a href="./index.html" class="logo">
            <img src="readme-images/forjafinal1.png" alt="Filmlane logo">
          </a>

          <button class="menu-close-btn" data-menu-close-btn>
            <ion-icon name="close-outline"></ion-icon>
          </button>

        </div>

        <ul class="navbar-list">

          <li>
            <a href="./index.php" class="navbar-link">Home</a>
          </li>

          <li>
          <a href="./index.php" class="navbar-link">Movies</a>
          </li>
          <li>
            <a href="#" class="navbar-link">My orders</a>
          </li>
          <li>
          <a href="wishlist.php?user_id=<?php echo $user_id; ?>" class="wishlist">My wishlists</a>
          </li>

        </ul>

        <ul class="navbar-social-list">

          <li>
            <a href="#" class="navbar-social-link">
              <ion-icon name="logo-twitter"></ion-icon>
            </a>
          </li>

          <li>
            <a href="#" class="navbar-social-link">
              <ion-icon name="logo-facebook"></ion-icon>
            </a>
          </li>

          <li>
            <a href="#" class="navbar-social-link">
              <ion-icon name="logo-pinterest"></ion-icon>
            </a>
          </li>

          <li>
            <a href="#" class="navbar-social-link">
              <ion-icon name="logo-instagram"></ion-icon>
            </a>
          </li>

          <li>
            <a href="#" class="navbar-social-link">
              <ion-icon name="logo-youtube"></ion-icon>
            </a>
          </li>

        </ul>

      </nav>

    </div>
  </header>





  <main>
    <article>

      <!-- 
        - #MOVIE DETAIL
      -->

      <?php
// Assuming you have a database connection established in $conn

// Get the movie_id from the URL
$movie_id = isset($_GET['movie_id']) ? $_GET['movie_id'] : 0;

// Ensure the movie_id is valid (positive integer)
if (!is_numeric($movie_id) || $movie_id <= 0) {
    echo "Invalid movie ID.";
    exit;
}

// Query to get movie details from the movies table
$query = "SELECT m.title, m.description, m.release_year, m.rating, m.trailer, m.poster, m.duration
          FROM movies m 
          WHERE m.movie_id = $movie_id";

// Check if the query executed successfully
$result = $conn->query($query);

if ($result === false) {
    // If the query failed, display an error message
    echo "Error executing query: " . $conn->error;
    exit;
}

if ($result->num_rows > 0) {
    $movie = $result->fetch_assoc();
} else {
    // If no movie is found, handle the error (e.g., redirect or show a message)
    echo "Movie not found!";
    exit;
}

// Query to get movie genres from the movie_genres table
$query_genres = "SELECT genre FROM movie_genres WHERE movie_id = $movie_id";
$result_genres = $conn->query($query_genres);

if ($result_genres === false) {
    echo "Error fetching genres: " . $conn->error;
    exit;
}

$genres = [];
while ($row = $result_genres->fetch_assoc()) {
    $genres[] = $row['genre'];
}
?>

<section class="movie-detail">
    <div class="container">
        <!-- Movie Banner -->
        <figure class="movie-detail-banner">
            <!-- Update the image source to match the movie's poster -->
            <img src="http://localhost/forja/images/posters/<?php echo htmlspecialchars($movie['poster']); ?>" alt="<?php echo htmlspecialchars($movie['title']); ?> movie poster">
            <button class="play-btn">
                <ion-icon name="play-circle-outline"></ion-icon>
            </button>
        </figure>

        <div class="movie-detail-content">
            <p class="detail-subtitle">New Movies</p>

            <h1 class="h1 detail-title">
                <?php echo htmlspecialchars($movie['title']); ?>
            </h1>

            <div class="meta-wrapper">
                <div class="badge-wrapper">
                    <!-- Update the rating or age restriction based on the database value -->
                    <div class="badge badge-fill"><?php echo $movie['rating'] >= 8 ? 'PG 13' : 'PG'; ?></div>
                    <div class="badge badge-outline"><?php echo $movie['rating'] >= 8 ? 'HD' : '4K'; ?></div>
                </div>

                <div class="ganre-wrapper">
                    <?php
                    // Display the genres
                    foreach ($genres as $genre) {
                        echo '<a href="#">' . htmlspecialchars($genre) . '</a>';
                    }
                    ?>
                </div>

                <div class="date-time">
                    <div>
                        <ion-icon name="calendar-outline"></ion-icon>
                        <time datetime="<?php echo $movie['release_year']; ?>"><?php echo $movie['release_year']; ?></time>
                    </div>

                    <div>
                        <ion-icon name="time-outline"></ion-icon>
                        <time datetime="PT<?php echo $movie['duration']; ?>M"><?php echo $movie['duration']; ?> min</time>
                    </div>
                </div>
            </div>

            <p class="storyline">
                <?php echo nl2br(htmlspecialchars($movie['description'])); ?>
            </p>

            <div class="details-actions">
                <!-- Share Button (with a trailer link, adjust accordingly) -->
                <button class="share">
                <ion-icon name="videocam-outline"></ion-icon>
                    <span>Watch trailer</span>
                </button>

                <!-- Rent Now Button (you can adjust the link or functionality here) -->
                <button class="btn btn-primary">
                    <ion-icon name="play"></ion-icon>
                    <span>Rent now!</span>
                </button>

                <!-- Heart Button to Like -->
                <button class="like">
    <a href="add_to_wishlist.php?movie_id=<?php echo $movie_id; ?>" class="heart-link">
        <ion-icon name="heart" class="heart-icon <?php echo $is_in_wishlist ? 'liked' : ''; ?>"></ion-icon>
    </a>
</button>

                
            </div>
        </div>
    </div>
</section>



      <section >
        <div class="rating-form">
          <h2>Give us your opinion about this film</h2>
          <form method="POST" action="add_to_reviews.php?movie_id=<?php echo $movie_id; ?>" >
              <div class="form-group">
                  <label for="rating">Rating(From 1 to 10)</label>
                  <input type="number" id="rating" name="rating" min="1" max="10" step="0.1" required>
              </div>
              <div class="form-group">
                  <label for="review">If you want to add a statement</label>
                  <textarea id="review" name="review" rows="4" required></textarea>
              </div>
              <button type="submit">Send</button>
          </form>
      </div>

      </section>





      <!-- 
        - #TV SERIES
      -->

      

    </article>
  </main>





  <!-- 
    - #FOOTER
  -->

  <footer class="footer">

    <div class="footer-top">
      <div class="container">

        <div class="footer-brand-wrapper">

          <a href="./index.html" class="logo">
            <img src="readme-images/forjafinal1.png" alt="Filmlane logo" width="150" height="50">
          </a>

          <ul class="footer-list">

            <li>
              <a href="./index.html" class="footer-link">Home</a>
            </li>

            <li>
              <a href="#" class="footer-link">Movie</a>
            </li>

           

            <li>
              <a href="#" class="footer-link">My orders</a>
            </li>
            <li>
            <a href="wishlist.php?user_id=<?php echo $user_id; ?>" class="wishlist">My wishlists</a>
            </li>

          </ul>

        </div>

        <div class="divider"></div>

        <div class="quicklink-wrapper">

          <ul class="quicklink-list">

            <li>
              <a href="#" class="quicklink-link">Faq</a>
            </li>

            <li>
              <a href="#" class="quicklink-link">Help center</a>
            </li>

            <li>
              <a href="#" class="quicklink-link">Terms of use</a>
            </li>

            <li>
              <a href="#" class="quicklink-link">Privacy</a>
            </li>

          </ul>

          <ul class="social-list">

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-facebook"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-twitter"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-pinterest"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-linkedin"></ion-icon>
              </a>
            </li>

          </ul>

        </div>

      </div>
    </div>

    <div class="footer-bottom">
      <div class="container">

        <p class="copyright">
          &copy; 2024 <a href="#">Forja.com</a>. All Rights Reserved
        </p>

        
      </div>
    </div>

  </footer>





  <!-- 
    - #GO TO TOP
  -->

  <a href="#top" class="go-top" data-go-top>
    <ion-icon name="chevron-up"></ion-icon>
  </a>





  <!-- 
    - custom js link
  -->
  <script src="./assets/js/script.js"></script>

  <!-- 
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>

</html>