START TRANSACTION;

-- -----------------------------------------------------------------------------------------
-- Database: `forja_db`
-- -----------------------------------------------------------------------------------------

-- Table structure for table `admin`
CREATE TABLE `admin` (
  `admin_id` INT PRIMARY KEY AUTO_INCREMENT,
  `username` VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `admin` (`username`, `password`, `email`) VALUES
('admin', 'admin123', 'admin@filmrental.com');

-- -----------------------------------------------------------------------------------------

-- Table structure for table `users`
CREATE TABLE `users` (
  `user_id` INT PRIMARY KEY AUTO_INCREMENT,
  `username` VARCHAR(255) NOT NULL,
  `first_name` VARCHAR(255) NOT NULL,
  `last_name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(15),
  `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------------------

-- Table structure for table `movies`
CREATE TABLE `movies` (
  `movie_id` INT PRIMARY KEY AUTO_INCREMENT,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NOT NULL,
  `release_year` YEAR NOT NULL,
  `rating` DECIMAL(2,1) NOT NULL,
  `trailer` VARCHAR(255) NOT NULL,
  `poster` VARCHAR(255) NOT NULL,
  `duration` INT NOT NULL,
  `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `movies` (`title`, `description`, `release_year`, `rating`, `trailer`, `poster`, `duration`) VALUES
('Inception', 'A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O., but his tragic past may doom the project and his team to disaster.', 2010, 8.8, 'trailer1.mp4', 'poster1.jpg', 148),
('The Matrix', 'When a beautiful stranger leads computer hacker Neo to a forbidding underworld, he discovers the shocking truth--the life he knows is the elaborate deception of an evil cyber-intelligence.', 1999, 8.7, 'trailer2.mp4', 'poster2.jpg', 136),
('The Godfather', 'The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son.', 1972, 9.2, 'trailer3.mp4', 'poster3.jpg', 175),
('The Dark Knight', 'When a menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman, James Gordon and Harvey Dent must work together to put an end to the madness.', 2008, 9.0, 'trailer4.mp4', 'poster4.jpg', 152),
('Pulp Fiction', 'The lives of two mob hitmen, a boxer, a gangster and his wife, and a pair of diner bandits intertwine in four tales of violence and redemption.', 1994, 8.9, 'trailer5.mp4', 'poster5.jpg', 154),
('Forrest Gump', "The history of the United States from the 1950s to the '70s unfolds from the perspective of an Alabama man with an IQ of 75, who yearns to be reunited with his childhood sweetheart.", 1994, 8.8, 'trailer6.mp4', 'poster6.jpg', 142),
('Fight Club', 'An insomniac office worker and a devil-may-care soap maker form an underground fight club that evolves into much more.', 1999, 8.8, 'trailer7.mp4', 'poster7.jpg', 139),
('The Shawshank Redemption', 'A banker convicted of uxoricide forms a friendship over a quarter century with a hardened convict, while maintaining his innocence and trying to remain hopeful through simple compassion.', 1994, 9.3, 'trailer8.mp4', 'poster8.jpg', 142),
('Interstellar', 'When Earth becomes uninhabitable in the future, a farmer and ex-NASA pilot, Joseph Cooper, is tasked to pilot a spacecraft, along with a team of researchers, to find a new planet for humans.', 2014, 8.6, 'trailer9.mp4', 'poster9.jpg', 169),
('Gladiator', 'A former Roman General sets out to exact vengeance against the corrupt emperor who murdered his family and sent him into slavery.', 2000, 8.5, 'trailer10.mp4', 'poster10.jpg', 155),
('Avengers: Endgame', 'After the devastating events of Avengers: Infinity War (2018), the universe is in ruins. With the help of remaining allies, the Avengers assemble once more in order to reverse Thanos actions and restore balance to the universe.', 2019, 8.4, 'trailer11.mp4', 'poster11.jpg', 181),
('The Lord of the Rings: The Return of the King', "Gandalf and Aragorn lead the World of Men against Sauron's army to draw his gaze from Frodo and Sam as they approach Mount Doom with the One Ring.", 2003, 9.0, 'trailer12.mp4', 'poster12.jpg', 201),
('Titanic', 'A seventeen-year-old aristocrat falls in love with a kind but poor artist aboard the luxurious, ill-fated R.M.S. Titanic.', 1997, 7.9, 'trailer13.mp4', 'poster13.jpg', 195),
('The Lion King', 'Lion prince Simba and his father are targeted by his bitter uncle, who wants to ascend the throne himself.', 1994, 8.5, 'trailer14.mp4', 'poster14.jpg', 88),
('The Hangover', 'Three buddies wake up from a bachelor party in Las Vegas with no memory of the previous night and the bachelor missing. They must make their way around the city in order to find their friend in time for his wedding.', 2009, 7.7, 'trailer15.mp4', 'poster15.jpeg', 100),
('Clueless', "Shallow, rich and socially successful Cher is at the top of her Beverly Hills high school's pecking scale. Seeing herself as a matchmaker, Cher first coaxes two teachers into dating each other.", 1995, 6.9, 'trailer16.mp4', 'poster16.jpg', 97),
('10 Things I Hate About You', 'A high-school boy, Cameron, cannot date Bianca until her anti-social older sister, Kat, has a boyfriend. So, Cameron pays a mysterious boy, Patrick, to charm Kat.', 1999, 7.3, 'trailer17.mp4', 'poster17.jpg', 98),
('The Proposal', 'When New York editor Margaret faces deportation, she convinces her assistant Andrew to marry her in return for a promotion. However, when she visits his hometown, it changes her in many ways.', 2009, 6.8, 'trailer18.mp4', 'poster18.jpg', 108),
('Superbad', 'Two co-dependent high school seniors are forced to deal with separation anxiety after their plan to stage a booze-soaked party goes awry.', 2007, 7.6, 'trailer19.mp4', 'poster19.jpg', 113),
('Pitch Perfect', "Beca, a freshman at Barden University, is cajoled into joining The Bellas, her school's all-girls singing group. Injecting some much needed energy into their repertoire, The Bellas take on their male rivals in a campus competition.", 2012, 7.1, 'trailer20.mp4', 'poster20.jpg', 122);

-- -----------------------------------------------------------------------------------------

-- Table structure for `movie_genres`
CREATE TABLE `movie_genres` (
  `movie_id` INT NOT NULL,
  `genre` VARCHAR(50) NOT NULL, 
  FOREIGN KEY (`movie_id`) REFERENCES `movies`(`movie_id`) ON DELETE CASCADE,
  PRIMARY KEY (`movie_id`, `genre`) 
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `movie_genres` (`movie_id`, `genre`) VALUES
(1, 'Action'), (1, 'Sci-Fi'), (1, 'Thriller'),
(2, 'Action'), (2, 'Sci-Fi'), (2, 'Drama'),
(3, 'Crime'), (3, 'Drama'),
(4, 'Action'), (4, 'Crime'), (4, 'Drama'),
(5, 'Crime'), (5, 'Drama'),
(6, 'Drama'), (6, 'Romance'),
(7, 'Drama'), (7, 'Thriller'),
(8, 'Drama'), (8, 'Crime'),
(9, 'Adventure'), (9, 'Drama'), (9, 'Sci-Fi'),
(10, 'Action'), (10, 'Adventure'),
(11, 'Action'), (11, 'Sci-Fi'), (11, 'Adventure'),
(12, 'Action'), (12, 'Fantasy'),
(13, 'Drama'), (13, 'Romance'),
(14, 'Animation'), (14, 'Drama'),
(15, 'Comedy'),
(16, 'Comedy'), (16, 'Romance'),
(17, 'Comedy'), (17, 'Romance'),
(18, 'Comedy'), (18, 'Romance'),
(19, 'Comedy'),
(20, 'Comedy'), (20, 'Music');

-- -----------------------------------------------------------------------------------------

-- Table structure for table `rentals`
CREATE TABLE `rentals` (
  `rental_id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `movie_id` INT NOT NULL,
  `rental_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `return_date` TIMESTAMP NULL,
  `status` ENUM('rented', 'returned') DEFAULT 'rented',
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`movie_id`) REFERENCES `movies`(`movie_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------------------

-- Table structure for table `wishlist`
CREATE TABLE `wishlist` (
  `wishlist_id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `movie_id` INT NOT NULL,
  `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`movie_id`) REFERENCES `movies`(`movie_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------------------

-- Table structure for table `reviews`
CREATE TABLE `reviews` (
  `review_id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `movie_id` INT NOT NULL,
  `rating` DECIMAL(2,1) NOT NULL CHECK (`rating` BETWEEN 0 AND 10),
  `review_text` TEXT,
  `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`movie_id`) REFERENCES `movies`(`movie_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------------------

COMMIT;
